class Array
  # Write an Array method that returns a bubble-sorted copy of an array.
  # Do NOT call the built-in Array#sort method in your implementation.
  def bubble_sort(&prc)
    sorted_data = []
    return self if self.length == 1

    idx = 1
    while idx < self.length
      second = self[idx]
      first = self[idx - 1]

      if first < second
        sorted_data << first
      else
        sorted_data << second
      end
      # p "#{sorted_data} <= sorted_data | #{first} <= first | #{second} <= second"

      idx += 1
    end

    sorted_data
  end

  # You are not required to implement this; it's here as a suggestion :-)
  def bubble_sort!(&prc)
  end
end

# Write a method that will transpose a rectangular matrix (array of arrays)
def transpose(matrix)
  transposed = []

  idx = 0
  while idx < matrix.length
    transposed << []
    
    idx += 1
  end

  transposed
end

# Write a method called 'sum_rec' that
# recursively calculates the sum of an array of values
def sum_rec(nums)
  sum = 0
  return 0 if nums.length == 0
  facorize = sum_rec(nums[0...-1])
  sum += nums.last
  sum
end

class String
  # This method returns true if the string can be rearranged to form the
  # sentence passed as an argument.

  # Example:
  # "cats are cool".shuffled_sentence_detector("dogs are cool") => false
  # "cool cats are".shuffled_sentence_detector("cats are cool") => true

  def shuffled_sentence_detector(other)
    word1 = self.split(' ').sort
    word2 = other.split(' ').sort

    if word1 == word2
      return true
    end
    false
  end
end

# Write a method that returns the largest prime factor of a number
def largest_prime_factor(num)
  idx = num

  while idx >= 0
    return idx if prime?(idx) && num % idx == 0
    idx -= 1
  end
end

# You are not required to implement this; it's here as a suggestion :-)
def prime?(num)
  if num < 2
    return false
  end

  idx = 2
  while idx < num
    return false if num % idx == 0
    idx += 1
  end

  true
end

# # prime? test
# p "#{prime?(13)} <= should return true"
# p "#{prime?(14)} <= should return false"

class Array
  # Phew this is ugly but I'm moving on. HUZZAH!
  def my_each(&prc)
    dummy_data = self.dup

    idx = 0
    while idx < dummy_data.length
      self.pop
      self << prc.call(dummy_data[idx])
      idx += 1
    end

    self
  end
end

class Array
  # Write an array method that returns an array made up of the
  # elements in the array that return `true` from the given block
  def my_select(&prc)
    select_data = []
    self.each { |x| select_data << x if prc.call(x) }

    select_data
  end
end
